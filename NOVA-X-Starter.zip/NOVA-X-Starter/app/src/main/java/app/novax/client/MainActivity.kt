package app.novax.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

private val Bg = Color(0xFF090B14)
private val Panel = Color(0xFF151A2B)
private val Violet = Color(0xFF9B72FF)
private val Cyan = Color(0xFF55D6E8)
private val Muted = Color(0xFF9AA3B8)

data class RelayEntry(
    val id: String = UUID.randomUUID().toString(),
    val url: String,
    val kind: String,
    val label: String,
    val status: String = "بررسی نشده"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

@Composable
private fun NovaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nova_x", 0) }
    val scope = rememberCoroutineScope()
    var urlInput by remember { mutableStateOf("") }
    var labelInput by remember { mutableStateOf("") }
    var relayList by remember { mutableStateOf(loadRelays(prefs)) }
    var message by remember { mutableStateOf("برای شروع، لینک Relay خودت را اضافه کن.") }
    var busyId by remember { mutableStateOf<String?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Violet,
            secondary = Cyan, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).background(
                            Brush.linearGradient(listOf(Violet, Cyan)),
                            RoundedCornerShape(15.dp)
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Bolt, null, tint = Bg, modifier = Modifier.size(29.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("NOVA X", fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Text("RELAY CONTROL CENTER", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF1B2634), shape = RoundedCornerShape(50)) {
                        Text("BETA", Modifier.padding(horizontal = 12.dp, vertical = 6.dp), color = Cyan, fontSize = 11.sp)
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("مدیریت مسیرهای اتصال", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        Box(
                            Modifier.size(106.dp).background(
                                Brush.linearGradient(listOf(Color(0xFF32245D), Color(0xFF143C4B))),
                                RoundedCornerShape(53.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Link, null, tint = Color.White, modifier = Modifier.size(43.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("${relayList.size} Relay ذخیره‌شده", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("اتصال تونل در این نسخه هنوز به موتور شبکه متصل نشده است.", color = Muted, fontSize = 11.sp)
                    }
                }

                Text("افزودن Relay", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = labelInput, onValueChange = { labelInput = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("نام دلخواه (مثلاً Relay 1)") },
                    shape = RoundedCornerShape(14.dp)
                )
                OutlinedTextField(
                    value = urlInput, onValueChange = { urlInput = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("لینک Apps Script /exec یا Relay") },
                    placeholder = { Text("https://...") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    shape = RoundedCornerShape(14.dp)
                )
                Button(
                    onClick = {
                        val clean = urlInput.trim()
                        if (!clean.startsWith("https://")) {
                            message = "فقط لینک HTTPS معتبر وارد کن."
                        } else {
                            val isGas = clean.contains("script.google.com/macros/s/") && clean.endsWith("/exec")
                            val item = RelayEntry(
                                url = clean,
                                kind = if (isGas) "Apps Script" else "Relay",
                                label = labelInput.trim().ifBlank { if (isGas) "Google Apps Script" else "Relay جدید" }
                            )
                            relayList = relayList + item
                            saveRelays(prefs, relayList)
                            urlInput = ""; labelInput = ""
                            message = "${item.label} ذخیره شد. برای بررسی، دکمه تست را بزن."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("ذخیره Relay")
                }

                Text(message, color = Cyan, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Relayهای من", fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${relayList.size} مورد", color = Muted, fontSize = 12.sp)
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
                    items(relayList, key = { it.id }) { relay ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(13.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(relay.label, fontWeight = FontWeight.Bold)
                                        Text(relay.kind, color = Cyan, fontSize = 11.sp)
                                    }
                                    IconButton(onClick = {
                                        relayList = relayList.filterNot { it.id == relay.id }
                                        saveRelays(prefs, relayList)
                                    }) { Icon(Icons.Default.Delete, null, tint = Muted) }
                                }
                                Text(relay.url, color = Muted, fontSize = 10.sp, maxLines = 1)
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(relay.status, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                    OutlinedButton(
                                        enabled = busyId != relay.id,
                                        onClick = {
                                            scope.launch {
                                                busyId = relay.id
                                                val result = withContext(Dispatchers.IO) { checkRelay(relay.url) }
                                                relayList = relayList.map {
                                                    if (it.id == relay.id) it.copy(status = result) else it
                                                }
                                                saveRelays(prefs, relayList)
                                                message = "نتیجه تست ${relay.label}: $result"
                                                busyId = null
                                            }
                                        },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.Refresh, null, modifier = Modifier.size(15.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(if (busyId == relay.id) "در حال تست" else "تست لینک")
                                    }
                                }
                            }
                        }
                    }
                }
                Text(
                    "NOVA X • Relay manager preview • v0.1.0",
                    color = Color(0xFF68718A), fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

private fun loadRelays(prefs: android.content.SharedPreferences): List<RelayEntry> {
    return try {
        val array = JSONArray(prefs.getString("relays", "[]"))
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            RelayEntry(
                id = o.optString("id"), url = o.optString("url"),
                kind = o.optString("kind"), label = o.optString("label"),
                status = o.optString("status", "بررسی نشده")
            )
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveRelays(prefs: android.content.SharedPreferences, items: List<RelayEntry>) {
    val array = JSONArray()
    items.forEach {
        array.put(org.json.JSONObject().apply {
            put("id", it.id); put("url", it.url); put("kind", it.kind)
            put("label", it.label); put("status", it.status)
        })
    }
    prefs.edit().putString("relays", array.toString()).apply()
}

private fun checkRelay(link: String): String {
    return try {
        val url = if (link.contains("?")) "$link&action=health" else "$link?action=health"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            instanceFollowRedirects = true
        }
        val code = conn.responseCode
        conn.disconnect()
        if (code in 200..299) "پاسخ HTTP $code — لینک در دسترس است"
        else "پاسخ HTTP $code"
    } catch (e: Exception) {
        "خطا: ${e.javaClass.simpleName}"
    }
}
