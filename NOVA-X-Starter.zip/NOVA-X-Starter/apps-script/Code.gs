/**
 * NOVA X - Apps Script relay directory API
 *
 * This file manages a list of relay endpoints for the app.
 * It is NOT a traffic-forwarding VPN relay and does not bypass filtering.
 * Deploy as Web app; Execute as: Me.
 */
const APP_TITLE = "NOVA X Relay Directory";
const RELAYS_PROPERTY = "NOVA_X_RELAYS";

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || "list";
  if (action === "health") {
    return json_({ ok: true, app: APP_TITLE, time: new Date().toISOString() });
  }
  if (action === "list") {
    const raw = PropertiesService.getScriptProperties().getProperty(RELAYS_PROPERTY) || "[]";
    return json_({ ok: true, relays: JSON.parse(raw) });
  }
  return json_({ ok: false, error: "unknown_action" });
}

function doPost(e) {
  const body = JSON.parse((e && e.postData && e.postData.contents) || "{}");
  // Configure a secret in Script Properties as NOVA_X_ADMIN_KEY.
  const expected = PropertiesService.getScriptProperties().getProperty("NOVA_X_ADMIN_KEY");
  if (!expected || body.admin_key !== expected) {
    return json_({ ok: false, error: "unauthorized" });
  }
  if (body.action === "replace") {
    if (!Array.isArray(body.relays)) return json_({ ok: false, error: "relays_must_be_array" });
    const safe = body.relays.filter(x =>
      x && typeof x.url === "string" &&
      /^https:\/\//i.test(x.url) &&
      typeof x.name === "string"
    ).slice(0, 100);
    PropertiesService.getScriptProperties().setProperty(RELAYS_PROPERTY, JSON.stringify(safe));
    return json_({ ok: true, count: safe.length });
  }
  return json_({ ok: false, error: "unknown_action" });
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
